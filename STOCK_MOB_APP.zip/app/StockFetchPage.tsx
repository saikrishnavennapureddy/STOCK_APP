import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, FlatList, ScrollView } from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import axios from 'axios';
import { Picker } from '@react-native-picker/picker';

const StockDetailsForm = () => {
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [numberOfRows, setNumberOfRows] = useState('');
  const [minPercentageChange, setMinPercentageChange] = useState<string>('');
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isStartTimePickerVisible, setStartTimePickerVisibility] = useState(false);
  const [isEndTimePickerVisible, setEndTimePickerVisibility] = useState(false);
  const [stockDetails, setStockDetails] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState('');
  const [tableName,setTableName]=useState('');


  useEffect(()=>{
    console.log(selectedIndex)
  },[selectedIndex])
  const fetchStockDetails = async () => {
    const rows = parseInt(numberOfRows);
    if(selectedIndex=="NIFTY50"){
      setTableName("stocks");
    }
    else{
      setTableName("nifty500stocks")
    }

    try {
      const response = await axios.post('http://192.168.1.4:4000/fetch-stock-details', {
        tableName,
        selectedDate,
        startTime,
        endTime,
        numberOfRows: parseInt(numberOfRows, 10),
        minPercentageChange,
       // Send the selected index to the backend
      });
      setStockDetails(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleDateConfirm = (date: Date) => {
    const formattedDate = date.toISOString().split('T')[0];
    setSelectedDate(formattedDate);
    hideDatePicker();
  };

  const showStartTimePicker = () => {
    setStartTimePickerVisibility(true);
  };

  const hideStartTimePicker = () => {
    setStartTimePickerVisibility(false);
  };

  const handleStartTimeConfirm = (date: Date) => {
    const time = date.toTimeString().split(' ')[0];
    setStartTime(time);
    hideStartTimePicker();
  };

  const showEndTimePicker = () => {
    setEndTimePickerVisibility(true);
  };

  const hideEndTimePicker = () => {
    setEndTimePickerVisibility(false);
  };

  const handleEndTimeConfirm = (date: Date) => {
    const time = date.toTimeString().split(' ')[0];
    setEndTime(time);
    hideEndTimePicker();
  };

  return (
    <ScrollView showsHorizontalScrollIndicator={false} contentInsetAdjustmentBehavior="automatic" contentContainerStyle={styles.safeAreaContainer} >
      <View style={styles.container}>
        <Text>Select Index:</Text>
        <Picker
          selectedValue={selectedIndex}
          onValueChange={(itemValue) => setSelectedIndex(itemValue)}
          style={styles.picker}
        >
          <Picker.Item label="NIFTY50" value="NIFTY50" />
          <Picker.Item label="NIFTY500" value="NIFTY500" />
        </Picker>

        <Text>Select Date:</Text>
        <Button title={selectedDate || "Select Date"} onPress={showDatePicker} />
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="date"
          onConfirm={handleDateConfirm}
          onCancel={hideDatePicker}
        />

        <Text>Select Start Time:</Text>
        <Button title={startTime || "Select Start Time"} onPress={showStartTimePicker} />
        <DateTimePickerModal
          isVisible={isStartTimePickerVisible}
          mode="time"
          onConfirm={handleStartTimeConfirm}
          onCancel={hideStartTimePicker}
        />

        <Text>Select End Time:</Text>
        <Button title={endTime || "Select End Time"} onPress={showEndTimePicker} />
        <DateTimePickerModal
          isVisible={isEndTimePickerVisible}
          mode="time"
          onConfirm={handleEndTimeConfirm}
          onCancel={hideEndTimePicker}
        />

        <Text>Number of Rows:</Text>
        <TextInput
          style={styles.input}
          value={numberOfRows}
          onChangeText={setNumberOfRows}
          keyboardType="numeric"
          placeholder="enter number"
        />

        <Text>Min Volume %:</Text>
        <TextInput
          style={styles.input}
          value={minPercentageChange}
          onChangeText={setMinPercentageChange}
          keyboardType="numeric"
          placeholder="enter number"
        />

        <Button title="Fetch Stock Details" onPress={fetchStockDetails} />

        {stockDetails.length > 0 && (
          <View style={styles.resultContainer}>
            <Text style={styles.resultTitle}>Stock Details:</Text>
            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <Text style={styles.tableHeaderCell}>Stock Name</Text>
                <Text style={styles.tableHeaderCell}>Latest Timestamp</Text>
                <Text style={styles.tableHeaderCell}>Latest Volume</Text>
                <Text style={styles.tableHeaderCell}>Previous Timestamp</Text>
                <Text style={styles.tableHeaderCell}>Avg Volume (Last {numberOfRows})</Text>
                <Text style={styles.tableHeaderCell}>Volume Change</Text>
                <Text style={styles.tableHeaderCell}>Volume Change (%)</Text>
              </View>
              <FlatList
                data={stockDetails}
                keyExtractor={(item) => item.stockname}
                renderItem={({ item }) => (
                  <View style={styles.tableRow}>
                    <Text style={styles.tableCell}>{item.stockname}</Text>
                    <Text style={styles.tableCell}>{item.latest_timestamp}</Text>
                    <Text style={styles.tableCell}>{item.latest_volume}</Text>
                    <Text style={styles.tableCell}>{item.previous_timestamp}</Text>
                    <Text style={styles.tableCell}>{item.avg_volume_last_4}</Text>
                    <Text style={styles.tableCell}>{item.volume_change}</Text>
                    <Text style={styles.tableCell}>{item.volume_change_percentage}%</Text>
                  </View>
                )}
              />
            </View>
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: 'white'
  },
  safeAreaContainer: {
    flexGrow: 1,
  },
  picker: {
    height: 50,
    marginVertical: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 10,
  },
  resultContainer: {
    marginTop: 20,
  },
  resultTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  table: {
    borderWidth: 1,
    borderColor: '#ccc',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f0f0f0',
  },
  tableHeaderCell: {
    flex: 1,
    padding: 10,
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: '#ccc',
  },
  tableRow: {
    flexDirection: 'row',
  },
  tableCell: {
    flex: 1,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    fontSize: 8,
  },
});

export default StockDetailsForm;

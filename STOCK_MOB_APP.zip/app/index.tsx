import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, Button, FlatList } from 'react-native';
import axios from 'axios';
import { router } from 'expo-router';

const App = () => {
  const [stockName, setStockName] = useState('');
  const [stocks, setStocks] = useState([]);

  const fetchStocks = async () => {
    try {
      const response = await axios.get('http://192.168.1.3:4000/stocks', {
        params: { stockName }
      });
      const sortedStocks = response.data.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
      const latestStocks = sortedStocks.slice(0, 2);
      if(stockName!=''){setStocks(latestStocks)}
      else{setStocks(response.data)};
      console.log(latestStocks);
    } catch (error) {
      console.error('Error fetching stocks:', error);
    }
  };

  function convertToLocalDateTimeString(
    isoDateString: string,
    locale: string = 'en-US',
    options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric',
      hour12: true
    }
  ): string {
    const date = new Date(isoDateString);
    return date.toLocaleString(locale, options);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Stock Lookup</Text>

      <Button  title='Next' onPress={()=>router.push('/StockFetchPage')}></Button>
      <TextInput
        style={styles.input}
        placeholder="Enter stock name"
        value={stockName}
        onChangeText={setStockName}
      />
      <Button title="Search" onPress={fetchStocks} />
      <FlatList
        data={stocks}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Text style={styles.cell}>{item.id}</Text>
            <Text style={styles.cell}>{item.stockname}</Text>
            <Text style={styles.cell}>{item.lastprice}</Text>
            <Text style={styles.cell}>{item.volume}</Text>
            <Text style={styles.cell}>{convertToLocalDateTimeString(item.timestamp)}</Text>
          </View>
        )}
        ListHeaderComponent={() => (
          <View style={styles.headerRow}>
            <Text style={styles.headerCell}>ID</Text>
            <Text style={styles.headerCell}>Name</Text>
            <Text style={styles.headerCell}>Price</Text>
            <Text style={styles.headerCell}>Volume</Text>
            <Text style={styles.headerCell}>Timestamp</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff'
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center'
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8
  },
  row: {
    flexDirection: 'row',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc'
  },
  cell: {
    flex: 1,
    textAlign: 'center'
  },
  headerRow: {
    flexDirection: 'row',
    paddingVertical: 8,
    borderBottomWidth: 2,
    borderBottomColor: '#000'
  },
  headerCell: {
    flex: 1,
    textAlign: 'center',
    fontWeight: 'bold'
  }
});

export default App;

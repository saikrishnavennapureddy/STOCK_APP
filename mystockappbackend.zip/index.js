const express = require("express");
const { KiteConnect } = require("kiteconnect");

require("dotenv").config();

const app = express();
const port = 4000;


const sql = require('mssql/msnodesqlv8');


var config={
  server:'SAI\\SQLEXPRESS',
  driver:'msnodesqlv8',
  database:'self2',
  options:{
    trustedConnection:true
  }

}

sql.connect(config,function(err){
  if(err){
    console.log(err)
  }
  else{
    console.log("success")
  }
})
app.use(express.json());

const apikey = process.env.KITE_API_KEY;
const apiSecret = process.env.KITE_API_SECRET;
const kc = new KiteConnect({ api_key: apikey });

// Create a Redis client
const redisClient = redis.createClient({
  host: '127.0.0.1',
  port: 6379
});

// Handle Redis client errors
redisClient.on('error', (err) => {
  console.error('Error connecting to Redis:', err);
});

// Middleware to check Redis client readiness
function ensureRedisClient(req, res, next) {
  if (redisClient.connected) {
    next();
  } else {
    res.status(500).send('Redis client not connected');
  }
}

app.get("/login", (req, res) => {
  const loginUrl = kc.getLoginURL();
  res.redirect(loginUrl);
});

app.get("/redirect", (req, res) => {
  const reqtoken = req.query.request_token;
  kc.generateSession(reqtoken, apiSecret)
    .then(async function(response) {
      console.log(response);
      const accesstoken = response.access_token;
      kc.setAccessToken(accesstoken);

      try {
        const profile = await kc.getProfile();
        console.log("Profile:", profile);
      } catch (err) {
        console.log("Error:", err);
      }

      res.send("Login success");
    })
    .catch(function(err) {
      console.log(err);
    });
});

app.get("/quote", (req, res) => {
  const reqtoken = req.query.request_token;
  kc.generateSession(reqtoken, apiSecret)
    .then(response => {
      console.log("Access Token:", response.access_token);
      kc.setAccessToken(response.access_token);

      const instruments = [
        "NSE:RELIANCE", "NSE:TCS", "NSE:HDFCBANK", "NSE:HDFC", "NSE:INFY", "NSE:ICICIBANK",
        "NSE:KOTAKBANK", "NSE:HINDUNILVR", "NSE:SBIN", "NSE:BHARTIARTL", "NSE:ITC", "NSE:BAJFINANCE",
        "NSE:ASIANPAINT", "NSE:AXISBANK", "NSE:HCLTECH", "NSE:MARUTI", "NSE:LT", "NSE:ULTRACEMCO",
        "NSE:WIPRO", "NSE:SUNPHARMA", "NSE:TITAN", "NSE:NESTLEIND", "NSE:INDUSINDBK", "NSE:ONGC",
        "NSE:POWERGRID", "NSE:NTPC", "NSE:BAJAJFINSV", "NSE:GRASIM", "NSE:TECHM", "NSE:HEROMOTOCO",
        "NSE:HDFCLIFE", "NSE:CIPLA", "NSE:SBILIFE", "NSE:DRREDDY", "NSE:ADANIPORTS", "NSE:M&M",
        "NSE:DIVISLAB", "NSE:TATASTEEL", "NSE:BRITANNIA", "NSE:COALINDIA", "NSE:BPCL", "NSE:SHREECEM",
        "NSE:JSWSTEEL", "NSE:EICHERMOT", "NSE:TATAMOTORS", "NSE:UPL", "NSE:APOLLOHOSP", "NSE:ICICIPRULI",
        "NSE:ADANIENT"
      ];

      kc.getQuote(instruments)
        .then(data => {
          // Extract required fields and push to Redis
          Object.keys(data).forEach(key => {
            const { instrument_token, buy_quantity, sell_quantity, volume } = data[key];
            const redisData = {
              instrument_token,
              buy_quantity,
              sell_quantity,
              volume
            };
            redisClient.set("1",{name:"sai"})
            redisClient.set(`quote:${instrument_token}`, JSON.stringify(redisData), (err, reply) => {
              if (err) {
                console.error("Error setting data in Redis:", err);
              } else {
                console.log(`Data for instrument ${instrument_token} saved to Redis`);
              }
            });
          });
          res.send("Quote data pushed to Redis");
        })
        .catch(err => {
          console.error("Error fetching live data:", err);
          res.status(500).send("Error fetching live data");
        });
    })
    .catch(err => {
      console.error("Error generating session:", err);
      res.status(500).send("Error generating session");
    });
});

// Route to get all data from Redis
app.get("/redis-data", ensureRedisClient, (req, res) => {
  redisClient.keys('quote:*', (err, keys) => {
    if (err) {
      console.error("Error fetching keys from Redis:", err);
      return res.status(500).send("Error fetching keys from Redis");
    }

    if (keys.length === 0) {
      return res.status(404).send("No data found in Redis");
    }

    redisClient.mget(keys, (err, values) => {
      if (err) {
        console.error("Error fetching data from Redis:", err);
        return res.status(500).send("Error fetching data from Redis");
      }

      const result = keys.map((key, index) => ({
        key,
        data: JSON.parse(values[index])
      }));

      res.json(result);
    });
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}/login`);
});

const express = require("express");
const { KiteConnect } = require("kiteconnect");

require("dotenv").config();

const app = express();
const port = 4000;

const mysql = require('mysql2');

// Create a connection to the database
const connection = mysql.createConnection({
  host: 'localhost', // Your host name
  user: 'root', // Your database user
  password: '1234', // Your password
  database: 'self' // Your database name
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ', err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});
app.use(express.json());

const apikey = process.env.KITE_API_KEY;
const apiSecret = process.env.KITE_API_SECRET;
const kc = new KiteConnect({ api_key: apikey });

// Create a Redis client


// Middleware to check Redis client readiness


app.get("/login", (req, res) => {
  const loginUrl = kc.getLoginURL();
  res.redirect(loginUrl);
});

app.get("/redirect", (req, res) => {
  const reqtoken = req.query.request_token;
  kc.generateSession('UkFSbRqJkC3bOcglO1l9egaH1VWwlkHX', apiSecret)
    .then(async function(response) {
      console.log(response);
      const accesstoken = response.access_token;
      kc.setAccessToken(accesstoken);

      try {
        const profile = await kc.getProfile();
        console.log("Profile:", profile);
      } catch (err) {
        console.log("Error:", err);
      }

      res.send("Login success");
    })
    .catch(function(err) {
      console.log(err);
    });
});

app.get("/quote", (req, res) => {
  const reqtoken = req.query.request_token;

  kc.generateSession(reqtoken, apiSecret)
    .then(response => {
      console.log("Access Token:", response.access_token);
      kc.setAccessToken(response.access_token);

      const instruments = [
        "NSE:RELIANCE", "NSE:TCS", "NSE:HDFCBANK", "NSE:HDFC", "NSE:INFY", "NSE:ICICIBANK",
        "NSE:KOTAKBANK", "NSE:HINDUNILVR", "NSE:SBIN", "NSE:BHARTIARTL", "NSE:ITC", "NSE:BAJFINANCE",
        "NSE:ASIANPAINT", "NSE:AXISBANK", "NSE:HCLTECH", "NSE:MARUTI", "NSE:LT", "NSE:ULTRACEMCO",
        "NSE:WIPRO", "NSE:SUNPHARMA", "NSE:TITAN", "NSE:NESTLEIND", "NSE:INDUSINDBK", "NSE:ONGC",
        "NSE:POWERGRID", "NSE:NTPC", "NSE:BAJAJFINSV", "NSE:GRASIM", "NSE:TECHM", "NSE:HEROMOTOCO",
        "NSE:HDFCLIFE", "NSE:CIPLA", "NSE:SBILIFE", "NSE:DRREDDY", "NSE:ADANIPORTS", "NSE:M&M",
        "NSE:DIVISLAB", "NSE:TATASTEEL", "NSE:BRITANNIA", "NSE:COALINDIA", "NSE:BPCL", "NSE:SHREECEM",
        "NSE:JSWSTEEL", "NSE:EICHERMOT", "NSE:TATAMOTORS", "NSE:UPL", "NSE:APOLLOHOSP", "NSE:ICICIPRULI",
        "NSE:ADANIENT"
      ];

      async function yourAsyncCallbackFunction() {
        console.log("This function is called every 5 minutes");
        kc.getQuote(instruments)
        .then(data => {
          // Extract required fields and push to Redis
          console.log(data)
          Object.keys(data).forEach(key => {
            const { instrument_token, buy_quantity, sell_quantity, volume, timestamp } = data[key];
            const redisData = {
              instrument_token,
              buy_quantity,
              sell_quantity,
              volume
            };
           

          const sql = 'INSERT INTO stocks (instrument_token, buy_quantity, sell_quantity, volume,timestamp,stockname) VALUES (?, ?, ?, ?,?,?)';
          connection.query(sql, [instrument_token, buy_quantity, sell_quantity, volume,timestamp,key.split(':')[1]], (err, results) => {
            if (err) {
              console.error("Error inserting data into MySQL:", err);
            } else {
              console.log(`Data for instrument ${instrument_token} saved to MySQL`);
            }
          });
        });
          res.send("Quote data pushed to Mysql");
        })
        .catch(err => {
          console.error("Error fetching live data:", err);
          res.status(500).send("Error fetching live data");
        });

      }

      setInterval(() => {
        yourAsyncCallbackFunction().catch(console.error);
      }, 1000);

    })
    .catch(err => {
      console.error("Error generating session:", err);
      res.status(500).send("Error generating session");
    });
});

// Route to get all data from Redis


  
  
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}/login`);
});

const twilio = require('twilio');

const accountSid = 'ACdf9417284346689eec5f4d7a30a641fc'; // Your Account SID from www.twilio.com/console
const authToken = 'bcfb63eae402783b4b0f450fbae2132b';   // Your Auth Token from www.twilio.com/console

const client = new twilio(accountSid, authToken);

const sendWhatsAppMessage = async (to, message) => {
  try {
    const response = await client.messages.create({
      body: message,
      from: 'whatsapp:+14155238886', // This is a Twilio sandbox number for WhatsApp
      to: `whatsapp:${to}`
    });
    console.log('Message sent:', response.sid);
  } catch (error) {
    console.error('Error sending message:', error);
  }
};

// Example usage
sendWhatsAppMessage('+919705282482', 'Hello from Twilio Node js!');

const express = require("express");
const { KiteConnect } = require("kiteconnect");
require("dotenv").config();
const mysql = require('mysql2');

const app = express();
const port = 4000;

// Create a connection to the database
const connection = mysql.createConnection({
  host: 'localhost', // Your host name
  user: 'root', // Your database user
  password: '1234', // Your password
  database: 'self' // Your database name
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ', err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});

app.use(express.json());

const apikey = process.env.KITE_API_KEY;
const apiSecret = process.env.KITE_API_SECRET;
const kc = new KiteConnect({ api_key: apikey });

app.get("/login", (req, res) => {
  const loginUrl = kc.getLoginURL();
  res.redirect(loginUrl);
});

app.get("/redirect", (req, res) => {
  const reqtoken = req.query.request_token;
  kc.generateSession(reqtoken, apiSecret)
    .then(async function (response) {
      console.log(response);
      const accesstoken = response.access_token;
      kc.setAccessToken(accesstoken);

      try {
        const profile = await kc.getProfile();
        console.log("Profile:", profile);
      } catch (err) {
        console.log("Error:", err);
      }

      res.send("Login success");
    })
    .catch(function (err) {
      console.log(err);
      res.status(500).send("Error generating session");
    });
});

app.get("/quote", (req, res) => {
  const reqtoken = req.query.request_token;

  kc.generateSession(reqtoken, apiSecret)
    .then(response => {
      console.log("Access Token:", response.access_token);
      kc.setAccessToken(response.access_token);

      const instruments = [
        "NSE:RELIANCE", "NSE:TCS", "NSE:HDFCBANK", "NSE:HDFC", "NSE:INFY", "NSE:ICICIBANK",
        "NSE:KOTAKBANK", "NSE:HINDUNILVR", "NSE:SBIN", "NSE:BHARTIARTL", "NSE:ITC", "NSE:BAJFINANCE",
        "NSE:ASIANPAINT", "NSE:AXISBANK", "NSE:HCLTECH", "NSE:MARUTI", "NSE:LT", "NSE:ULTRACEMCO",
        "NSE:WIPRO", "NSE:SUNPHARMA", "NSE:TITAN", "NSE:NESTLEIND", "NSE:INDUSINDBK", "NSE:ONGC",
        "NSE:POWERGRID", "NSE:NTPC", "NSE:BAJAJFINSV", "NSE:GRASIM", "NSE:TECHM", "NSE:HEROMOTOCO",
        "NSE:HDFCLIFE", "NSE:CIPLA", "NSE:SBILIFE", "NSE:DRREDDY", "NSE:ADANIPORTS", "NSE:M&M",
        "NSE:DIVISLAB", "NSE:TATASTEEL", "NSE:BRITANNIA", "NSE:COALINDIA", "NSE:BPCL", "NSE:SHREECEM",
        "NSE:JSWSTEEL", "NSE:EICHERMOT", "NSE:TATAMOTORS", "NSE:UPL", "NSE:APOLLOHOSP", "NSE:ICICIPRULI",
        "NSE:ADANIENT"
      ];

      const fetchAndInsertData = () => {
        kc.getQuote(instruments)
          .then(data => {
            // Extract required fields and insert into MySQL
            Object.keys(data).forEach(key => {
              const { instrument_token, buy_quantity, sell_quantity, last_price, volume, timestamp } = data[key];
              const sql = 'INSERT INTO stocks (instrument_token, buy_quantity, sell_quantity, lastprice, volume, timestamp, stockname) VALUES (?, ?, ?, ?, ?, ?, ?)';
              connection.query(sql, [instrument_token, buy_quantity, sell_quantity, last_price, volume, new Date(), key.split(':')[1]], (err, results) => {
                if (err) {
                  console.error("Error inserting data into MySQL:", err);
                } else {
                  console.log(`Data for instrument ${instrument_token} saved to MySQL`);
                }
              });
            });
          })
          .catch(err => {
            console.error("Error fetching live data:", err);
          });
      };

      // Fetch and insert data immediately
      fetchAndInsertData();

      // Set interval to continue fetching and inserting data every 3 minutes
      setInterval(fetchAndInsertData, 180000);

      res.send("Quote data will be pushed to MySQL every 3 minutes");
    })
    .catch(err => {
      console.error("Error generating session:", err);
      res.status(500).send("Error generating session");
    });
});

app.get('/stocks', (req, res) => {
  
  const stockName = req.query.stockName;
  if(stockName!=''){
  const query = 'SELECT * FROM stocks WHERE stockname = ?';

  connection.query(query, [stockName], (error, results) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    res.json(results);
  });
}
else{
  const query="SELECT t1.* FROM stocks t1 JOIN (  SELECT stockname, timestamp FROM stocks WHERE (stockname, timestamp) IN ( SELECT stockname, timestamp  FROM (   SELECT stockname, timestamp, ROW_NUMBER() OVER (PARTITION BY stockname ORDER BY timestamp DESC) as row_num FROM stocks) t WHERE t.row_num <= 2) ) t2 ON t1.stockname = t2.stockname AND t1.timestamp = t2.timestamp ORDER BY t1.stockname, t1.timestamp DESC;";
  connection.query(query,(error,results)=>{
    if(error){
      return res.status(500).json({error:error.message})
    }
    res.json(results)
  })
}
});


app.post('/fetch-stock-details', (req, res) => {
  const { selectedDate, startTime, endTime, numberOfRows } = req.body;

  const query = `
    WITH ranked_data AS (
        SELECT stockname, timestamp, volume,
               ROW_NUMBER() OVER (PARTITION BY stockname ORDER BY timestamp DESC) AS row_num
        FROM stocks
        WHERE DATE(timestamp) = ?
          AND TIME(timestamp) BETWEEN ? AND ?
    ),
    latest_four_records AS (
        SELECT stockname, timestamp, volume, row_num
        FROM ranked_data
        WHERE row_num <= ?
    ),
    latest_data AS (
        SELECT stockname,
               MAX(CASE WHEN row_num = 1 THEN timestamp END) AS latest_timestamp,
               MAX(CASE WHEN row_num = 1 THEN volume END) AS latest_volume,
               MAX(CASE WHEN row_num = 4 THEN timestamp END) AS previous_timestamp,
               AVG(volume) AS avg_volume_last_4
        FROM latest_four_records
        GROUP BY stockname
    )
    SELECT ld.stockname,
           ld.latest_timestamp,
           ld.latest_volume,
           ld.previous_timestamp,
           ld.avg_volume_last_4,
           COALESCE(ld.latest_volume - ld.avg_volume_last_4, 0) AS volume_change,
           CASE
               WHEN ld.avg_volume_last_4 > 0 THEN ((ld.latest_volume - ld.avg_volume_last_4) / ld.avg_volume_last_4) * 100
               ELSE NULL
           END AS volume_change_percentage
    FROM latest_data ld
    ORDER BY ld.stockname;
  `;
  connection.query(query, [selectedDate, startTime, endTime, numberOfRows], (error, results) => {
    if (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
      console.log(results)
    }
  });
});


app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}/login`);
});
